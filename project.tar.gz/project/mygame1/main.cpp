#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.loadFromModule("mygame1", "Main");

    // 注册Background单例
    //qmlRegisterSingletonType(QUrl("qrc:/path/to/Background.qml"), "Game.Background", 1, 0, "Background");

    //qmlRegisterSingletonType(QUrl("qrc:/qt/qml/mygame1/Background.qml"), "MyGame", 1, 0, "Background");

    return app.exec();
}
